import numpy as np
import matplotlib.pyplot as plt
from scipy.io import wavfile

def read_short_segment(wav_path, duration_sec=0.1):
    rate, data = wavfile.read(wav_path)
    if data.ndim > 1:
        data = data[:, 0]
    num_samples = int(rate * duration_sec)
    return rate, data[:num_samples]

def plot_spectrum_line_segment(wav_path, label, color, duration_sec=0.1, linestyle='-'):
    rate, data = read_short_segment(wav_path, duration_sec)
    data = data.astype(np.float32)
    N = len(data)
    yf = np.fft.rfft(data)
    xf = np.fft.rfftfreq(N, 1 / rate)
    plt.plot(xf, np.abs(yf), label=label, color=color, linewidth=1, linestyle=linestyle, alpha=0.9)

def compare_spectrum_lines_segment(original_wav, attacked_wav, output_img="image.png", max_freq=2000, duration_sec=0.1):
    plt.figure(figsize=(12, 6))
    plot_spectrum_line_segment(original_wav, "Original", "blue", duration_sec, '-')
    plot_spectrum_line_segment(attacked_wav, "Attacked", "red", duration_sec, '--')
    plt.xlabel("Frequency (Hz)")
    plt.ylabel("Spectral amplitude")
    plt.title(f"Frequency spectrum Comparison (first {duration_sec} second")
    plt.legend()
    plt.xlim(0, max_freq)
    plt.tight_layout()
    plt.savefig(output_img, dpi=150)
    print(f"Saved in {output_img}")

if __name__ == "__main__":
    compare_spectrum_lines_segment("output.wav", "attacked.wav", duration_sec=0.1, max_freq=2000)

