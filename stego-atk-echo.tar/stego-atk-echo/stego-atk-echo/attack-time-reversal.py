import numpy as np
from scipy.io import wavfile

def time_reversal_attack(signal, block_size=2048, reverse_prob=0.5):
    attacked = np.copy(signal)
    total_samples = len(signal) if signal.ndim == 1 else signal.shape[0]
    for i in range(0, total_samples, block_size):
        if np.random.rand() < reverse_prob:
            end = min(i + block_size, total_samples)
            if signal.ndim == 1:
                attacked[i:end] = attacked[i:end][::-1]
            else:
                attacked[i:end, :] = attacked[i:end, :][::-1, :]
    return attacked

def attack_wav(input_wav, output_wav):
    rate, data = wavfile.read(input_wav)
    data = data.astype(np.float32)
    attacked = time_reversal_attack(data, block_size=2048, reverse_prob=0.5)
    attacked = np.clip(attacked, -32768, 32767).astype(np.int16)
    wavfile.write(output_wav, rate, attacked)
    print(f"Time reversal attack saved: {output_wav}")

if __name__ == "__main__":
    attack_wav("output.wav", "attacked_time_reversal.wav")

