import numpy as np
from scipy.io import wavfile
from scipy.signal import resample

def time_scale_attack(signal, factor):
    new_length = int(len(signal) / factor)
    if signal.ndim == 1:
        return resample(signal, new_length)
    else:
        return np.stack([resample(signal[:, ch], new_length) for ch in range(signal.shape[1])], axis=1)

def attack_wav(input_wav, output_wav, factor=1.01):
    rate, data = wavfile.read(input_wav)
    data = data.astype(np.float32)
    attacked = time_scale_attack(data, factor)
    attacked = np.clip(attacked, -32768, 32767).astype(np.int16)
    wavfile.write(output_wav, int(rate * factor), attacked)
    print(f"Time-scale attack written: {output_wav}")

if __name__ == "__main__":
    attack_wav("output.wav", "attacked_timescale.wav", factor=1.01)
