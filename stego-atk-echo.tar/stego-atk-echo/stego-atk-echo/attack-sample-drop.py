import numpy as np
from scipy.io import wavfile

def drop_samples(signal, drop_rate=0.01):
    """
    Xóa ngẫu nhiên các mẫu trong tín hiệu.
    drop_rate: tỉ lệ mẫu bị xóa (1% = 0.01).
    """
    total_samples = signal.shape[0]
    keep_mask = np.random.rand(total_samples) > drop_rate
    if signal.ndim == 1:
        return signal[keep_mask]
    else:
        return signal[keep_mask, :]

def attack_wav(input_wav, output_wav, drop_rate=0.01):
    rate, data = wavfile.read(input_wav)
    data = data.astype(np.float32)
    attacked = drop_samples(data, drop_rate=drop_rate)
    attacked = np.clip(attacked, -32768, 32767).astype(np.int16)
    wavfile.write(output_wav, rate, attacked)
    print(f"Sample-drop attack: {output_wav} (drop_rate={drop_rate})")

if __name__ == "__main__":
    attack_wav("output.wav", "attacked_sample_drop.wav", drop_rate=0.01)
