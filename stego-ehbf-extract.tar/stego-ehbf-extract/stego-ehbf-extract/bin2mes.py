with open("output.txt", "r") as f:
    bits = f.read().strip()

bits = bits[:len(bits) - len(bits) % 8]
message = ""

for i in range(0, len(bits), 8):
    byte = bits[i:i+8]
    message += chr(int(byte, 2))

with open("output_message.txt", "w") as f:
    f.write(message)

print(f"Transfer complete! Here is message: {message}")
