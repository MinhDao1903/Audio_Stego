import numpy as np
import wave
import sys
import scipy.signal
import scipy.interpolate

def split_to_n_segments(input: np.ndarray, n: int):
    return np.asanyarray(
        np.array_split(input[:int(np.floor(len(input)/n) * n)], n)
    ), input[int(np.floor(len(input)/n) * n):]

def spread_bits(secret_data: np.ndarray, signal_length: int) -> np.ndarray:
    mixer, rest = split_to_n_segments(np.ones(signal_length), len(secret_data))
    mixer = mixer * secret_data[:, None]
    return np.append(mixer, rest)

def to_dtype(input: np.ndarray, dtype):
    input = np.asanyarray(input)
    max = 1.0
    try:
        max = np.iinfo(input.dtype).max
    except ValueError:
        pass
    out = input / max
    out = out.astype(np.float64)
    max = 1.0
    try:
        max = np.iinfo(dtype).max
    except ValueError:
        pass
    out = out * max
    out = out.astype(dtype)
    return out

def autocorr_scipy_correlate(x):
    result = scipy.signal.correlate(x, x, mode='full')
    return result[len(result)//2:]

def center(input: np.ndarray) -> np.ndarray:
    return input - np.mean(input)

def normalize(input: np.ndarray) -> np.ndarray:
    if len(input) > 0 and np.abs(input).max() != 0:
        input = input / np.abs(input).max()
    return input

class EchoBF:
    def __init__(self, source_data, secret_data=None):
        self._source_data = source_data
        self._secret_data = secret_data if secret_data is not None else np.array([], dtype=np.uint8)

    def _encode(self, d0: int, d1: int, alpha=0.5, decay_rate=0.85):
        secret_len = self._secret_data.size
        if secret_len == 0 or d0 >= d1:
            return self._source_data, {
                'd0': -1,
                'd1': -1,
                'l': 0,
            }

        mixer = spread_bits(self._secret_data, self._source_data.size)
        source_pad = np.pad(self._source_data, d1) * alpha/2

        echo_0_fwd = source_pad[d1-d0:]
        echo_0_bwd = source_pad[d1+d0:]
        echo_1_fwd = source_pad
        echo_1_bwd = source_pad[d1+d1:]

        encoded = (
            self._source_data[:len(mixer)] +
            echo_1_fwd[:len(mixer)] * mixer +
            echo_1_bwd[:len(mixer)] * mixer +
            echo_0_fwd[:len(mixer)] * np.abs(1-mixer) +
            echo_0_bwd[:len(mixer)] * np.abs(1-mixer)
        )

        encoded = center(encoded)
        encoded = normalize(encoded)
        encoded = to_dtype(encoded, self._source_data.dtype)

        return encoded, {
            'd0': d0,
            'd1': d1,
            'l': secret_len,
        }

    def encode(self, d0=, d1=, alpha=0.5, decay_rate=0.85):
        return self._encode(d0, d1, alpha, decay_rate)

    def decode(self, d0: int, d1: int, l: int):
        if l < 1:
            return np.empty(0, dtype=np.uint8), {}

        split, _ = split_to_n_segments(self._source_data, l)
        decoded = np.zeros(len(split), dtype=np.uint8)

        for i, segment in enumerate(split):
            cn = autocorr_scipy_correlate(
                np.fft.irfft(np.log(np.abs(np.fft.rfft(segment)))**2)
            )
            if cn[d0] > cn[d1]:
                decoded[i] = 0
            else:
                decoded[i] = 1

        return decoded, {}

def read_wav(filename):
    with wave.open(filename, 'rb') as wf:
        params = wf.getparams()
        frames = wf.readframes(params.nframes)
        audio = np.frombuffer(frames, dtype=np.int16)

        if params.nchannels == 2:
            audio = audio.reshape(-1, 2)
            audio = np.round(audio.mean(axis=1)).astype(np.int16)
            params = params._replace(nchannels=1)
    return audio, params

def write_wav(filename, audio, params):
    with wave.open(filename, 'wb') as wf:
        wf.setparams(params)
        wf.writeframes(audio.astype(np.int16).tobytes())

def read_bin_txt(filename):
    with open(filename, 'r') as f:
        bits = f.read().strip()
    return np.array([int(b) for b in bits], dtype=np.uint8)

def main(wav_in, txt_in, wav_out, meta_out, d0=, d1=):
    audio, params = read_wav(wav_in)
    secret = read_bin_txt(txt_in)
    echo = EchoBF(audio, secret)
    encoded, info = echo.encode(d0=d0, d1=d1)
    write_wav(wav_out, encoded, params)
    with open(meta_out, 'w') as f:
        f.write(f"{info['d0']} {info['d1']} {info['l']}\n")
    print(f"Done. Params used: d0={info['d0']}, d1={info['d1']}, l={info['l']} (saved in {meta_out})")

if __name__ == "__main__":
    if len(sys.argv) != 5:
        print("Usage: python hide_echo_bf.py <input.wav> <secret.txt> <output.wav> <meta.txt>")
        exit(1)
    main(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])
