message = "hello world!"
bits = ''.join(format(ord(c), '08b') for c in message)

with open("input_message.txt", "w") as f:
    f.write(bits)

print("Message has been transfered and saved in input_message.txt")
